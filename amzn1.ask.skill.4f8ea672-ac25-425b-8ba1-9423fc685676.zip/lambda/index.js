// This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
// Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
// session persistence, api calls, and more.
const Alexa = require('ask-sdk-core');
  var max = 100;
    var Random = [];
    
    
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        let clip1 = 'https://randomise1234.s3.ap-south-1.amazonaws.com/drum+roll.mp3';
        const speakOutput = 'Hello ,  glad to see you .' +  'Welcome, to housie game,' +  '<audio src="' + clip1 +'"/>' +  'There are one to hundred numbers in my pocket,i will say those one by one randomly,,The one who has first got all the numbers said by me is the winner,say help to get through the instructions again or yes to start the game' ;
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
const GameIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GameIntent';
    },
    handle(handlerInput) {
        
  let speakOutput = '';
   let repromptOutput =' Shall we proceed for the next number?';
       { 
            function generateRan(){
  
    for(var i = 0;i<max-99 ; i++){
        var temp = Math.floor(Math.random()*max+1);
        if(Random.indexOf(temp) === -1){
            Random.push(temp);
             speakOutput+=`i got ${temp} `+ '<break time="2s"/>';
        }
        else
         i--;
         
    }
    
 
           
            }


generateRan();  
       
           } 
        return handlerInput.responseBuilder
            
             .speak(speakOutput + repromptOutput)
            .reprompt(repromptOutput)
           
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
           
            
       }
    };
    
    
    const CheckIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CheckIntent';
    },
    handle(handlerInput) {
        
        let speakOutput = ' ';
         { 
            
   
   
        speakOutput+='i will verify your ticket ' + '<break time="2s"/>' + ' The numbers which i prompted are';
    
 var repromptOutput = `${Random}` ; 
         }
        
        
        return handlerInput.responseBuilder
            .speak(speakOutput +repromptOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
    

    
    
    
    
    
    
const NameIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest' &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === 'NameIntent';
    },
    handle(handlerInput) {
        const username = handlerInput.requestEnvelope.request.intent.slots.name.value;
        let name1 = username.toLowerCase();
        
 let clip1 = 'https://randomise1234.s3.ap-south-1.amazonaws.com/drum+roll.mp3';
     //   let clip2 = 'https://randomise1234.s3.ap-south-1.amazonaws.com/Jack+and+Jill.mp3';
       
      
         const speakOutput = 'Here is our winner ' + name1 + '<break time="2s"/>' + '<audio src="' + clip1 +'"/>';      //+ '" />' + '<audio src="' + clip2 + '" />' +  ' enjoy!';//

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput =  ',i will pick numbers one to hundred  randomly , if you have those numbers in your ticket then say'  +   'check the ticket for verification  ,,shall we start the game  .';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye! thank you soo much for playing ,Hope i see you next time';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

// The intent reflector is used for interaction model testing and debugging.
// It will simply repeat the intent the user said. You can create custom handlers
// for your intents by defining them above, then also adding them to the request
// handler chain below.
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;




        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

// Generic error handling to capture any syntax or routing errors. If you receive an error
// stating the request handler chain is not found, you have not implemented a handler for
// the intent being invoked or included it in the skill builder below.
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.stack}`);
        const speakOutput = `Sorry, I had trouble doing what you asked. Please try again.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

// The SkillBuilder acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        GameIntentHandler,
        CheckIntentHandler,
//        NumberIntentHandler,
        NameIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler, // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    )
    .addErrorHandlers(
        ErrorHandler,
    )
    .lambda();
